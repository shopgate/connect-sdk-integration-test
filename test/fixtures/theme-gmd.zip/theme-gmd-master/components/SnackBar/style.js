import { css } from 'glamor';

const drawer = css({
  width: '100%',
  background: 'black',
  padding: '7px 24px',
}).toString();

export default {
  drawer,
};
