import { css } from 'glamor';

const container = css({
  marginBottom: '35px',
}).toString();

export default {
  container,
};
