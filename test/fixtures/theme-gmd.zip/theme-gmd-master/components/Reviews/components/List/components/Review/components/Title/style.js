import { css } from 'glamor';

export default css({
  fontWeight: 500,
  lineHeight: '20px',
}).toString();
