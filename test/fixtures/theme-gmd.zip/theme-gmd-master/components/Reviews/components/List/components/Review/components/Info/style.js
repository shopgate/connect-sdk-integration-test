import { css } from 'glamor';
import colors from 'Styles/colors';

export default css({
  color: colors.shade3,
  fontSize: 14,
}).toString();

