import { css } from 'glamor';

export default css({
  fontSize: 14,
  fontStyle: 'italic',
  whiteSpace: 'pre-line',
}).toString();
