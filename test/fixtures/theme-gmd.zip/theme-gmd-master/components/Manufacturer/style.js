import { css } from 'glamor';
import colors from 'Styles/colors';

export default css({
  color: colors.primary,
}).toString();
