import { css } from 'glamor';

export default css({
  margin: '0 auto',
  maxHeight: '100%',
});
