import { css } from 'glamor';
import colors from 'Styles/colors';

const list = css({
  background: colors.background,
}).toString();

export default {
  list,
};
