/**
 * Value to recalculate the rating average.
 * @type {number}
 */
export const RATING_SCALE_DIVISOR = 20;
