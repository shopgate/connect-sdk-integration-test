export const SET_VIEW_TITLE = 'SET_VIEW_TITLE';
export const SET_VIEW_TOP = 'SET_VIEW_TOP';
