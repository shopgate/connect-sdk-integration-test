import { css } from 'glamor';

export default css({
  padding: '6px 5px 6px 18px',
  textOverflow: 'ellipsis',
  whiteSpace: 'nowrap',
  overflow: 'hidden',
}).toString();
