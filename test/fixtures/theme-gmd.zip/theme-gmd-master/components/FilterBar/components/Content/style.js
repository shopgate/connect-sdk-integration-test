import { css } from 'glamor';

export default css({
  display: 'flex',
}).toString();
