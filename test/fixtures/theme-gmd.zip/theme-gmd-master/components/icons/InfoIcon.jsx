import React from 'react';
import Icon from '@shopgate/pwa-common/components/Icon';

// SVG Content
const content = '<path d="M0 0h24v24H0z" fill="none"/><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-6h2v6zm0-8h-2V7h2v2z"/>';

/**
 * The info icon component.
 * @param {Object} props The component properties.
 * @returns {JSX}
 */
const Info = props => <Icon content={content} {...props} />;

export default Info;
