export const QUICKLINKS_MENU = 'quicklinks';
