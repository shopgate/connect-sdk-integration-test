export const GRID_VIEW = 'grid';
export const LIST_VIEW = 'list';

export const SET_CATEGORY_VIEW_MODE = 'SET_CATEGORY_VIEW_MODE';
