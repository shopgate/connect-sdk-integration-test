export const CART_MAX_ITEMS = 99;
export const CART_INPUT_AUTO_SCROLL_DELAY = 500;
