import { css } from 'glamor';
import colors from 'Styles/colors';

export default css({
  color: `${colors.shade4}`,
}).toString();
