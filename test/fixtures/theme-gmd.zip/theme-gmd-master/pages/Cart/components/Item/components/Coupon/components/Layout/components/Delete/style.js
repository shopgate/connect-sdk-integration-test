import { css } from 'glamor';

export default css({
  padding: 0,
  fontSize: '1.5rem',
  marginTop: -2,
  marginRight: -5,
}).toString();
