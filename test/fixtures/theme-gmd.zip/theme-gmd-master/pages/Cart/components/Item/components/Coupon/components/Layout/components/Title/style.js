import { css } from 'glamor';

export default css({
  fontSize: 16,
  fontWeight: 500,
  lineHeight: 1.125,
  marginBottom: 4,
}).toString();
