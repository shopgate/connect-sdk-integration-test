import { css } from 'glamor';

export default css({
  marginBottom: 4,
}).toString();
