import { css } from 'glamor';
import colors from 'Styles/colors';

const text = css({
  color: colors.success,
}).toString();

export default {
  text,
};
