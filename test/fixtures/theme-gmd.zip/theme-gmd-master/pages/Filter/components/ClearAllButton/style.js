import { css } from 'glamor';

export default css({
  textAlign: 'right',
}).toString();
