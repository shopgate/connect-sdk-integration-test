/**
 * Number of reviews items that should be loaded per bundle (page or load more).
 * @type {number}
 */
export const REVIEW_ITEMS_PER_PAGE = 10;
