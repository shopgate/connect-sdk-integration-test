import { css } from 'glamor';

const button = css({
  width: '100%',
}).toString();

export default {
  button,
};
