import { css } from 'glamor';

const strikedPrice = css({
  fontSize: 11,
  textAlign: 'right',
}).toString();

export default {
  strikedPrice,
};
